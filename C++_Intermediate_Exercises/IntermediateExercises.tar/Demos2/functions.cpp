void f(int, int, int){}
void f(int, int){}
void f(int){}
int main()
{
	f(1);
	f(1,2);
	f(1,2,3);
}
